export interface AdoptionStory {
    id: number;
    title: string;
    summary: string;
    details: string;
    imageUrl: string;
    date: string;
  }