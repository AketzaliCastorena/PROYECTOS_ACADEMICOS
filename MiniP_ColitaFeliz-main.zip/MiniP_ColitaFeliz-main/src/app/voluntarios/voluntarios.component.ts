import { Component } from '@angular/core';

@Component({
  selector: 'app-voluntarios',
  standalone: true,
  imports: [],
  templateUrl: './voluntarios.component.html',
  styleUrl: './voluntarios.component.css'
})
export class VoluntariosComponent {

}
