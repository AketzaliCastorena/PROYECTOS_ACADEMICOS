export interface Preguntas{
    pregunta: string;
    respuesta: string;
    mostrarResp: boolean;
}