export interface Citas{
    imagen: string;
    nombre: string;
    edad: string;
    sexo: string;
    color: string;
    raza: string;
    tiempoR: string;
    comportamiento: string;
    nombreCte: string;
    telCte: string;
    fechaCte: null;
    horaCte: null;
}