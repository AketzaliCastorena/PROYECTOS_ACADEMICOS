import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-donacion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './donacion.component.html',
  styleUrl: './donacion.component.css'
})
export class DonacionComponent {

}
