import { Component } from '@angular/core';

@Component({
  selector: 'app-adopcion',
  standalone: true,
  imports: [],
  templateUrl: './adopcion.component.html',
  styleUrl: './adopcion.component.css'
})
export class AdopcionComponent {

}
